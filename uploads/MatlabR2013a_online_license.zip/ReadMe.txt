本私服支持授权R11~R2013a

R2012a(传统界面最后一版):
9174b27024488f97f62409f87e641058	https://software.ii.uib.no/ii/matlab/MATHWORKS_UNIX_R2012a.iso
89b9bf11143866aaf481426b71b97dcb	https://software.ii.uib.no/ii/matlab/MATHWORKS_WINDOWS_R2012a.iso

R2013a(现代界面，本私服支持授权的最后一版):
493b62a63351ad0d614c99ccb31842c4	https://software.ii.uib.no/ii/matlab/R2013a_UNIX.iso
b4c1f69a1e090b6a61f66d7c6e14dda8	https://software.ii.uib.no/ii/matlab/R2013a_Windows.iso

File Installation Key (FIK) 可以安装全部工具箱:
09806-07443-53955-64350-21751-41297  #安装除MATLAB Production Server外的工具箱
40236-45817-26714-51426-39281  #安装MATLAB Production Server（R2012b开始有此工具箱）

使用方法（R2012a Windows版为例）：
1、将network.lic放入C:\Program Files\MATLAB\R2012a\licenses\目录（没有就新建）中
2、运行C:\Program Files\MATLAB\R2012a\bin\matlab.exe启动MATLAB，联网授权需要等待1~2分钟，不要着急:)

备注：
license.dat这两个版本用不到，早期版本有用。例如R11要放入MATLAB\R11\bin\目录中，具体哪个版本才开始不用license.dat而用network.lic我没有测试。
