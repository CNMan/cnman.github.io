用于Windows XP wSP3安装KES 10 WIN SP1 MR4并正常更新

安装程序：
英文版：kes10winsp1_mr4_en_aes256.exe
简体中文版：kes10winsp1_mr4_zh-hans_aes256.exe
繁体中文版：kes10winsp1_mr4_zh-hant_aes256.exe

注册表：
恢复初始状态用：kes10sp1mr4.reg
恢复正常更新用：kes10sp1mr4_update_patch.reg
KES 10 WIN SP2 MR3 on Windows 10 LTSC 2019备份：kes10sp2mr3.reg
KES 10 WIN SP2 MR4 on Windows 10 LTSC 2019备份：kes10sp2mr4.reg
