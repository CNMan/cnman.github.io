0. Смонтируйте iso-образ  Matlab912R2022a_Win64.iso  в виртуальный диск.
     На виндовз 8 и ниже для этого может потребоваться программа типа Daemon Tools Lite (или любая подобная)

1. Запустите setup.exe на этом виртуальном диске и если вы видите запрос логина Mathworks (происходит когда у установщика есть доступ в интернет)
     то в правом верхнем углу в  "Advanced Options"  выберите режим установки  "I have a File Installation Key"
     Если доступа в интернет установщик не обнаружит, то требуемый режим установки будет выбран автоматом

2. Когда дойдете до  "Enter File Installation Key"  введите
     50874-33247-14209-37962-45495-25133-28159-33348-18070-60881-29843-35694-31780-18077-36759-35464-51270-19436-54668-35284-27811-01134-26918-26782-54088

3. Когда дойдете до  "Select License File"  выберите файл  "license.lic"  из папки с файлом Matlab912R2022a_Win64.iso

4. Далее выберите папку куда хотите поставить Матлаб (<matlabfolder>)

5. Когда дойдете до  "Select products"  поставьте галки на нужных вам компонентах
     Если будет выбрано всё, то Матлаб займет около 30Гигов. Если только  "MATLAB"  то примерно 3Гига
     Поэтому для экономии места и времени запуска отключайте то что вы не знаете или знаете что вам не нужно.
     Матлаб лучше ставить на SSD диск для повышения скорости запуска (а такие диски зачастую "не резиновые"). Так что думайте сами.

6. Когда дойдете до  "Select Options"  выберите галочку  "Add shortcut to desktop"

7. Прогресс установки компонентов может не отображаться корректно (например, всегда показывать 0%) ... просто ждите.
     Если процесс затянулся слишком долго следите растет ли размер папки куда ставите Матлаб.
     Если несколько минут размер не растет - перезапустите установку

8. По окончании установки скопируйте файл  "libmwlmgrimpl.dll"  из папки с файлом  Matlab912R2022a_Win64.iso
     в УЖЕ СУЩЕСТВУЮЩУЮ ПАПКУ  "<matlabfolder>\bin\win64\matlab_startup_plugins\lmgrimpl"
     C ПЕРЕЗАПИСЬЮ УЖЕ СУЩЕСТВУЮЩЕГО ФАЙЛА  (<matlabfolder> - папка куда вы выбрали установить Матлаб на шаге 4)
     Некоторые ошибаются, выполняя этот пункт (не внимательны). Поэтому слова про перезапись написаны большими буквами!!!
     Если при копировании файла вас не спросили про перезапись файла то вы сделали этот пункт не верно (ну либо Матлаб не установился)!

9. Если установщик не создал ярлык запуска Матлаба на рабочем столе (либо создал неверный ярлык)
     то либо создайте новый ярлык, либо измените неверный, так чтобы ярлык указывал на
     <matlabfolder>\bin\win64\MATLAB.exe

10. Можно работать :)


P.S.
Если установщик по ходу процесса завис где-то на 1-7 шаге то принудительно закройте установщик и начните заново с шага 1

P.S.2
При обновлении/дополнении уже работающего Матлаба пункт 3 можно не выполнять
А вот пункт 8 вероятно придется выполнять повторно (если в ходе дополнения/обновления файл  "libmwlmgrimpl.dll"  был перезаписан установщиком)
Если после обновления/дополнения Матлаба начала появляться ошибка при запуске Матлаба то первым делом стоит пробовать выполнить повторно пункт 8




0. Mount iso-file  Matlab912R2022a_Win64.iso  to virtual disk.
     For Windows 8 and lower you probably need soft like Daemon Tools Lite (or similar)

1. Run setup.exe from that virtual disk and if you see login/password/signin form (you gave access to internet for installer)
     then in upper right corner in  "Advanced Options"  select setup mode  "I have a File Installation Key"
     If internet access is absent then required setup mode will be auto-selected and you do not need to select in manually

2. When you will be asked to  "Enter File Installation Key"  enter
     50874-33247-14209-37962-45495-25133-28159-33348-18070-60881-29843-35694-31780-18077-36759-35464-51270-19436-54668-35284-27811-01134-26918-26782-54088

3. When you will be asked to  "Select License File"  select file  "license.lic"  from folder with  Matlab912R2022a_Win64.iso  file

4. Then select folder where you want Matlab to be installed (<matlabfolder>)

5. When you will be asked to  "Select products"  select components you need
     If you all components are selected Matlab will need about 30Gb of disk space and somewhat longer startup time
     If you select only  "MATLAB"  then Matlab will need about  3Gb of disk space
     You better install Matlab on SSD disk for better startup time, so most likely you do not want to waste SSD-disk space for nothing

6. Then in  "Select Options"  select  "Add shortcut to desktop"

7. Components setup progress may be shown incorrectly (for example always show 0%) ... just wait
     Or if installation process takes too long start to monitor size of <matlabfolder> folder
     If the size is not growing after several minutes then restart setup from step 1

8. After installation is done copy file  "libmwlmgrimpl.dll"  from folder with  Matlab912R2022a_Win64.iso  file
     to ALREADY EXISTING FOLDER  "<matlabfolder>\bin\win64\matlab_startup_plugins\lmgrimpl"
     WITH OVERWRITING OF EXISTING FILE (<matlabfolder> - is where you have selected to install Matlab on step 4)
     If you was NOT asked about overwriting then you are doing something wrong (or Matlab was not installed successfully)!!!

9. If desktop shortcut was not created (or was created bad shortcut)
     then create new shortcut or change existing one so that it run the
     "<matlabfolder>\bin\win64\MATLAB.exe"

10. Work with Matlab :)


P.S.
If setup hang in step 1-7 then force to close it and start setup again from step 1

P.S.2
During update/change of already working Matlab there is no need to execute step 3
Step 8 might be necessary to repeat (if during update/change of Matlab file  "libmwlmgrimpl.dll"  was overwritten)
If after update/change you get error during startup of Matlab then first try to redo the step 8
