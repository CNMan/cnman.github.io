0. Смонтируйте iso-образ  Matlab912R2022a_Lin64.iso

1. Запустите  "install"  из примонтированного iso-файла и если вы видите запрос логина Mathworks (т.е. у установщика есть доступ в интернет)
     то в правом верхнем углу в  "Advanced Options"  выберите режим установки  "I have a File Installation Key"
     Если доступа в интернет установщик не обнаружит, то требуемый режим установки будет выбран автоматом

2. Когда дойдете до  "Enter File Installation Key"  введите
     50874-33247-14209-37962-45495-25133-28159-33348-18070-60881-29843-35694-31780-18077-36759-35464-51270-19436-54668-35284-27811-01134-26918-26782-54088

3. Когда дойдете до  "Select License File"  выберите файл  "license.lic"  из папки с файлом  Matlab912R2022a_Lin64.iso

4. Далее выберите папку куда хотите поставить Матлаб (<matlabfolder>)
     Чтобы избежать проблем лучше <matlabfolder> выбирать такой чтобы у вас были все права на эту папку
     Если затрудняетесь выбрать сами то задайте например  "/home/<YourUserName>/Matlab/R2022a"

5. Когда дойдете до  "Select products"  поставьте галки на нужных вам компонентах
     Если будет выбрано всё, то Матлаб займет около 30Гигов. Если только  "MATLAB"  то примерно 3Гига
     Поэтому для экономии места и времени запуска отключайте то что вы не знаете или знаете что вам не нужно.
     Матлаб лучше ставить на SSD диск для повышения скорости запуска (а такие диски зачастую "не резиновые"). Так что думайте сами.

6. По окончании установки скопируйте файл  "libmwlmgrimpl.so"  из папки с файлом  Matlab912R2022a_Lin64.iso
     в УЖЕ СУЩЕСТВУЮЩУЮ ПАПКУ  "<matlabfolder>\bin\glnxa64\matlab_startup_plugins\lmgrimpl"
     C ПЕРЕЗАПИСЬЮ УЖЕ СУЩЕСТВУЮЩЕГО ФАЙЛА  (<matlabfolder> - папка куда вы выбрали установить Матлаб на шаге 4)
     Некоторые ошибаются, выполняя этот пункт (не внимательны). Поэтому слова про перезапись написаны большими буквами!!!
     Если при копировании файла вас не спросили про перезапись файла, то вы сделали этот пункт не верно (ну либо Матлаб не установился)!

7. Можно работать, запустив <matlabfolder>\bin\matlab :)


P.S.
При обновлении/дополнении уже работающего Матлаба пункт 3 можно не выполнять
А вот пункт 6 вероятно придется выполнять повторно (если в ходе дополнения/обновления файл  "libmwlmgrimpl.so"  был перезаписан установщиком)
Если после обновления/дополнения Матлаба начала появляться ошибка при запуске Матлаба то первым делом стоит пробовать выполнить повторно пункт 6




0. Mount iso-file  Matlab912R2022a_Lin64.iso

1. Run  "install"  from mounted iso-file and if you see login/password/signin form (installer has access to internet)
     then in upper right corner in  "Advanced Options"  select setup mode  "I have a File Installation Key"
     If internet access is absent then required setup mode will be auto-selected and you do not need to select in manually

2. When you will be asked to  "Enter File Installation Key"  enter
     50874-33247-14209-37962-45495-25133-28159-33348-18070-60881-29843-35694-31780-18077-36759-35464-51270-19436-54668-35284-27811-01134-26918-26782-54088

3. When you will be asked to  "Select License File"  select file  "license.lic"  from folder with  Matlab912R2022a_Lin64.iso  file

4. Then select folder where you want Matlab to be installed (<matlabfolder>)
     To avoid problems you need <matlabfolder> which have all access rights for you
     If it hard for you to select anything then use  "/home/<YourUserName>/Matlab/R2022a"  for example

5. When you will be asked to  "Select products"  select components you need
     If you all components are selected Matlab will need about 30Gb of disk space and somewhat longer startup time
     If you select only  "MATLAB"  then Matlab will need about  3Gb of disk space
     You better install Matlab on SSD disk for better startup time, so most likely you do not want to waste SSD-disk space for nothing

6. After installation is done copy file  "libmwlmgrimpl.so"  from folder with  Matlab912R2022a_Lin64.iso  file
     to ALREADY EXISTING FOLDER  "<matlabfolder>\bin\glnxa64\matlab_startup_plugins\lmgrimpl"
     WITH OVERWRITING OF EXISTING FILE (<matlabfolder> - is where you have selected to install Matlab on step 4)
     If you was NOT asked about overwriting then you are doing something wrong (or Matlab was not installed successfully)!!!

7. Work with Matlab :)


P.S.
During update/change of already working Matlab there is no need to execute step 3
Step 6 might be necessary to repeat (if during update/change of Matlab file  "libmwlmgrimpl.so"  was overwritten)
If after update/change you get error during startup of Matlab then first try to redo the step 6
