0. Запустите установку Матлаб из файла  "Matlab912R2022a_Mac64.dmg"

1. Если вы видите запрос логина Mathworks (т.е. у установщика есть доступ в интернет)
     то в правом верхнем углу в  "Advanced Options"  выберите режим установки  "I have a File Installation Key"
     Если доступа в интернет установщик не обнаружит, то требуемый режим установки будет выбран автоматом

2. Когда дойдете до  "Enter File Installation Key"  введите
     50874-33247-14209-37962-45495-25133-28159-33348-18070-60881-29843-35694-31780-18077-36759-35464-51270-19436-54668-35284-27811-01134-26918-26782-54088

3. Когда дойдете до  "Select License File"  выберите файл  "license.lic"  из папки с файлом  Matlab912R2022a_Mac64.dmg

4. Когда дойдете до  "Select products"  поставьте галки на нужных вам компонентах
     Если будет выбрано всё, то Матлаб займет около 30Гигов. Если только  "MATLAB"  то примерно 3Гига
     Поэтому для экономии места и времени запуска отключайте то что вы не знаете или знаете что вам не нужно.
     Матлаб лучше ставить на SSD диск для повышения скорости запуска (а такие диски зачастую "не резиновые"). Так что думайте сами.

5. По окончании установки скопируйте файл  "libmwlmgrimpl.dylib"  из папки с файлом  Matlab912R2022a_Mac64.dmg
     в УЖЕ СУЩЕСТВУЮЩУЮ ПАПКУ  "<matlabfolder>\bin\maci64\matlab_startup_plugins\lmgrimpl"
     C ПЕРЕЗАПИСЬЮ УЖЕ СУЩЕСТВУЮЩЕГО ФАЙЛА  (<matlabfolder> - папка куда вы установить Матлаб, обычно это  "/Applications/Matlab_R2022a.app")
     Некоторые ошибаются, выполняя этот пункт (не внимательны). Поэтому слова про перезапись написаны большими буквами!!!
     Если при копировании файла вас не спросили про перезапись файла, то вы сделали этот пункт не верно (ну либо Матлаб не установился)!

6. Можно работать :)


P.S.
При обновлении/дополнении уже работающего Матлаба пункт 3 можно не выполнять
А вот пункт 5 вероятно придется выполнять повторно (если в ходе дополнения/обновления файл  "libmwlmgrimpl.dylib"  был перезаписан установщиком)
Если после обновления/дополнения Матлаба начала появляться ошибка при запуске Матлаба то первым делом стоит пробовать выполнить повторно пункт 5




0. Run matlab setup from  Matlab912R2022a_Mac64.dmg"  file

1. If you see login/password/signin form (installer has access to internet)
     then in upper right corner in  "Advanced Options"  select setup mode  "I have a File Installation Key"
     If internet access is absent then required setup mode will be auto-selected and you do not need to select in manually

2. When you will be asked to  "Enter File Installation Key"  enter
     50874-33247-14209-37962-45495-25133-28159-33348-18070-60881-29843-35694-31780-18077-36759-35464-51270-19436-54668-35284-27811-01134-26918-26782-54088

3. When you will be asked to  "Select License File"  select file  "license.lic"  from folder with  Matlab912R2022a_Mac64.dmg  file

4. When you will be asked to  "Select products"  select components you need
     If you all components are selected Matlab will need about 30Gb of disk space and somewhat longer startup time
     If you select only  "MATLAB"  then Matlab will need about  3Gb of disk space
     You better run Matlab from SSD disk for better startup time, so most likely you do not want to waste SSD-disk space for nothing

5. After installation is done copy file  "libmwlmgrimpl.dylib"  from folder with  Matlab912R2022a_Mac64.dmg  file
     to ALREADY EXISTING FOLDER  "<matlabfolder>\bin\maci64\matlab_startup_plugins\lmgrimpl"
     WITH OVERWRITING OF EXISTING FILE (<matlabfolder> - is where you installed Matlab, defaults to  "/Applications/Matlab_R2022a.app")

6. Work with Matlab :)


P.S.
During update/change of already working Matlab there is no need to execute step 3
Step 5 might be necessary to repeat (if during update/change of Matlab file  "libmwlmgrimpl.dylib"  was overwritten)
If after update/change you get error during startup of Matlab then first try to redo the step 5
